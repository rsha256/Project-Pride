ROCKAWAY BEACH SCRIPT & SANS

Hi there!
Thank you for the purchase - I hope you will enjoy this typeface! The license document has more legal information but I'd like to break it down as simply as possible here.

*** This you CAN do with this typeface: 
Design something awesome and get paid for it. Create logos and brands for yourself or clients with this font. 

*** This you CAN’T do with this:
Sell it and/or redistribute it. Use it in an iOS or Android-app. Contact me for a license for that if you are interested. That's it.

If you have any problem and/or suggestion for further development of this typeface feel free to email me: daniel@feldt.nu.

Oh, and if you use the font anywhere I'd be super excited for a link where it's in use or a pic. Tweet me (@dafeld) or instagram a pic (tag @greatscott.se) or email me.

Thanks again and take care,
Daniel Feldt

